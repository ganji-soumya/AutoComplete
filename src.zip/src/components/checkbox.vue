<template>

<label class="container">
 <input @click="checking()" type="checkbox"/>
 <span  class="checkmark" :style="{ 'background-color':checkboxccolor(),'border-color': theme.main}" ></span>
  </label>

</template> 
<script>

export default ({

inject: {
    theme: 'theme'
  },

data() {
    return {
        check:false
    };
  },
    
  methods:{
    checkboxccolor()
    {
     
      if(this.check===true)
      
      return this.theme.main;
    },
    checking(){
      this.check=!this.check;
    }
  }
});
</script>
<style >
.container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  margin-left: 40px;
  cursor: pointer;
  
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  border:1px solid
 
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.container .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
</style>



