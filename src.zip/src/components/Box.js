import styled from "vue-styled-components";

import { color, fontSize, space, width } from "styled-system";

const Box = styled("div", {
  m: {
    type: [Number, String, Array]
  },
  mx: {
    type: [Number, String, Array]
  },
  my: {
    type: [Number, String, Array]
  },
  p: {
    type: [Number, String, Array]
  },
  px: {
    type: [Number, String, Array]
  },
  py: {
    type: [Number, String, Array]
  },
  width: {
    type: [Number, String, Array]
  },
  bg: String,
  color: String
})`
  ${space}
  ${width}
  ${fontSize}
  ${color}
`;

export default Box;
