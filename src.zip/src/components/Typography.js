import styled from "vue-styled-components";

import { space, fontSize, fontWeight, lineHeight, color } from "styled-system";


const Typography = styled("div", {
  fontWeight: String,
  fontSize: [Number, String, Array],
  m: {
    type: [Number, String, Array]
  },
  mx: {
    type: [Number, String, Array]
  },
  my: {
    type: [Number, String, Array]
  },
  p: {
    type: [Number, String, Array],
    default: 2
  },
  px: {
    type: [Number, String, Array]
  },
  py: {
    type: [Number, String, Array]
  },
  color: String
})`
  ${space}
  ${fontSize}
  ${fontWeight}
  ${lineHeight}
  ${color}
`;

export default Typography;
