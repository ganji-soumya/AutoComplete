const myTheme = {
 
    main: 'red',
    space:'50px',
    fontType: 'Arial'
    };
    
 export default myTheme;