const innerTheme = {
    
    main: 'yellow',
    space:'100px'
    };
    
 export default innerTheme;