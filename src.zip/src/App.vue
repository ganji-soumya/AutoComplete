<template>
    <div>
      <theme-provider :theme="outerTheme">
           <checkbox ></checkbox>
           <br><br>
        <theme-provider :theme="innerTheme">
           <checkbox ></checkbox> 
           <br> <br>
           <checkbox ></checkbox>
        </theme-provider>
             <br>
        <theme-provider :theme="nestedTheme">
           <checkbox ></checkbox> <br>
        </theme-provider>
     </theme-provider>
<theme-provider :theme="outerTheme">
  <wrapper>
 <div>
ThemeProvider example by applying outerTheme to it
 </div>
</wrapper>
  
 </theme-provider>

 <wrapper :theme="innerTheme" >
 <div>
ThemeProvider example by applying innerTheme to it
 </div>
 </wrapper>

    </div>

</template>

<script>

import { ThemeProvider } from './ThemeProvider';
import outerTheme from './outerTheme'
import checkbox from './components/checkbox.vue'
import innerTheme from './innerTheme'
import wrapper from './components/wrapper.vue'

export default ({
  components: { ThemeProvider, checkbox,wrapper},
  data() {
    return {
     nestedTheme: {
        main: 'blue',
            
      },
     outerTheme,innerTheme
    };
  },
  
});
</script>
<style>

</style>