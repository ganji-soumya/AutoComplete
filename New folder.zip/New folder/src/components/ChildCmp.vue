<template>
  <div>
    <h3 class="content">From ChildCmp component</h3>
    <p>{{i}} {{n}} {{p}}</p>
   
    
  </div>
</template>
<script>
  export default {
    name: "ChildCmp",
    props:{i:Number,n:Object,p:Array},
    
  };
</script>
<style >
  .content {
    color: blue;
    font-family: verdana;
  }
</style>
