<template>
  
    <h1 class="content">{{ msg }}</h1>
    
</template>

<script>
export default {
  name: 'HelloWorld',
 data:function() {
     return {msg: "ssssss"
     }
  }
}
</script>

<style scoped>
  .content {
    color: green;
    font-family: arial;
  }
</style>
