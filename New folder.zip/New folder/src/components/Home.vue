<template>
  <div>
    <img :src="image" />
    <router-view></router-view>
    <button @click="v">contact</button>
  </div>
</template>
<script>
import image from "./../assets/images/UI.png";
export default {
  data: function () {
    return {
      image: image,
    };
  },
methods:{
  v:function()
  {
     this.$router.push({path:"contact"});
  }
}
};
</script>
<style></style>
