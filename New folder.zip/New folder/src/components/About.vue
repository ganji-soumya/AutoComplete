<template>
  <div>
    UI & Markup Technologies are a must for every developer who is serious about
    today’s web application development. <br />
    The track caters to the need of fast changing requirements in the area of
    front-end web application development. <br /><br />UI & Markup Technology,
    founded in Dec 2014, is the strategic partner for learning and capability
    development <br />
    for different units at Infosys with the following objectives:
    <li>To be at the helm of UI technologies</li>
    <li>To develop subject matter experts in UI space</li>
    <li>To re-skill the workforce to meet business demand</li>
    <li>To reduce skill mismatch between supply and demand of fresh talents</li>
  </div>
</template>
<style></style>
