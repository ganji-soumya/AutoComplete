<template>
    <div id="app">
      <h3>Watch Property</h3>
      <hr />
      <h3>Vue schedule details:</h3>
      Mode: {{mode}} <br />
      Location:{{location}}<br /><br />
      <button @click="mode='VCR'">Change mode</button>
    </div>
    </template>
    <script>
     export default{
        name:"watch",
        data:function() {
           return {location: "Mysore",
          mode: "Classroom"
           }
        },
        watch: {
          mode: function (newVal, old) {
            console.log("newval", newVal);
            console.log("oldval", old);
            var md = this;
            setTimeout(function () {
              md.mode = "Classroom";
            }, 2000);
          },
        },
      };
    </script>
 
