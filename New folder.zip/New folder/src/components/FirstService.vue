<template>
  <div>
    <h4>Course schedule</h4>
    <ul>
      <li v-for="detail in details" :key="detail.id">
        {{ detail.name }} by {{ detail.educator }}
      </li>
    </ul>
  </div>
</template>
<script>
export default {
    name:"FirstService",
  data: function () {
    return { details: [] };
  },
  created() {
    this.$http.get("../data.json").then(function (daata) {
      console.log("data", daata);
      this.details = daata.data;
    });
  },
};
</script>
<style></style>
