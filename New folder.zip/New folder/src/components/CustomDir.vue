<template>
  <div>
    <h4>Employee Details</h4>
    <p v-colorIt:color="'blue'">{{ empName | to-uppercase }}</p>
    <p v-colorIt:color.shadow="'green'">{{ empId }}</p>
    <p>{{salary |to-INR| to-uppercase }}</p>
  </div>
</template>
<script>
export default {
  name: "CustomDirective",
  data: function() {
    return {
      empName: "Samual",
      empId: 681592,
      unit: "Technical",
      salary:25000
    };
  },
};
</script>
<style></style>