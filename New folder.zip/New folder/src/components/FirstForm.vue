<template>
<ValidationObserver v-slot="{invalid}">
<form @submit.prevent="v">


<div class="form-group">
<label for="uname">username:</label>
<ValidationProvider rules="namerequired" v-slot="{errors}">
<input id="uname" type="text" class="form-control" name="uname" v-model="c.uname">


<p :style="{color:'red'}"> {{  errors[0]  }} </p>
</ValidationProvider>
</div>
<div class="form-group">
<label >password:</label>
<ValidationProvider rules="passwordrequired" v-slot="{errors}">
<input type="password" class="form-control"  v-model="c.pw">


<p>{{errors[0]}}</p>
</ValidationProvider>
</div>

<div class="form-group">
<button type="submit" :disabled="invalid">submit</button>
</div>
</form>
<p v-if="!invalid">{{msg}}</p>
</ValidationObserver>

</template>


<script>

import { extend } from "vee-validate";
import { required } from "vee-validate/dist/rules";
extend("namerequired",{
    ...required,
    message:"username required",
});
extend("passwordrequired",{
    ...required,
    message:"password required",
});


export default{
    name:"FirstForm",
    data:function()
    {
       return { c:{
           uname:"",
           pw:""
              }  ,
              msg:"" }
    },
    methods:{
        v:function()
        {
            this.msg="submitted"
        }
    }
}
</script>



