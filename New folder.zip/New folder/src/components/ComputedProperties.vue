<template>
    <div id="app">
      <h3>Computed Property</h3>
      <hr />
      <br />
      <button @click="count++">Click</button>
      <p>{{count}}</p>
      <p>{{msg}}</p>
    </div>
</template>
    <script>
      export default{
        name:"ComputedProperties",
        data: function(){
           return {count: 1}
        },
        computed: {
          msg: function () {
            return this.count > 5 ? "Greater than 5" : "Less than 5";
          },
        },
      };
    </script>

