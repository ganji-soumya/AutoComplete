<template>
  <div>
    <h3>Course offerings</h3>
    <br />
    <router-view> </router-view>
    <h4>Other courses...</h4>
    Backbone <br />
    Polymer<br />
    Node<br />
    Jasmine<br />
  </div>
</template>
<style></style>
