<template>
  <div>
    <br />
    <h4>Contact Us:</h4>
    Any suggestions email to
    <a href="mailto:samual_123456@contactus.com">Samual123456</a>
    <br />
    ETA | UI Mysore
    <router-view></router-view>
  </div>
</template>
<style></style>
