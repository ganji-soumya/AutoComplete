<template>
  <div>
    <h3 class="content">From Parent component!</h3>
    
    <child-cmp  :i="id" :n="name" :p="place"></child-cmp>
    <button @click="sow">click</button>
    <div>some {{id}}</div>
  </div>
</template>
<script>
  import ChildCmp from "./ChildCmp.vue";
  export default {
    components: {
      "child-cmp": ChildCmp,
    },
    data:function()
    {
      return {
       id:1,
       name:{first:"ganji",last:"sow"},
       place:"hyd"
      }
    },
    methods:{
      sow:function()
      {
        alert("welcome"+this.id);
      }
    }
    
  };
</script>
<style >
  .content {
    color: green;
    font-family: arial;
  }
</style>
