<template>
  <div>
    <h4>Just launched...</h4>
    <router-link to="/training/Vue">Vue</router-link> <br />
    <router-link to="/training/React">React</router-link><br />
    <router-link to="/training/Angular">Angular</router-link><br />
    <router-link to="/training/Express">Express</router-link><br />
    <br />
    <router-view> </router-view>
  </div>
</template>
<style></style>
