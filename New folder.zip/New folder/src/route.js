// import AboutCmp from './components/About.vue';
// import HomeCmp from './components/Home.vue';
// import TrainingCmp from './components/Training.vue';
// import ContactCmp from './components/Contact.vue';
// export const routes = [
// {path: '' , component: HomeCmp},
// {path: '/about' , component: AboutCmp},
// {path: '/training' , component: TrainingCmp},
// {path: '/contact' , component: ContactCmp}
// ];

import AboutCmp from "./components/About.vue";
import HomeCmp from "./components/Home.vue";
import TrainingCmp from "./components/Training.vue";
import ContactCmp from "./components/Contact.vue";
import CourseCmp from "./components/Courses.vue";
import FirstForm from "./components/FirstForm.vue";
import CourseDetailsCmp from "./components/CourseDetails.vue";
export const routes = [
  {
    path: "",component: HomeCmp,
    children: [{ path: "", component: CourseCmp }],
  },
  { path: "/about", component: AboutCmp },
  {
    path: "/training",component: TrainingCmp,
    children: [{ path: "", component: CourseCmp },
    { path: ":id", component: CourseDetailsCmp },],
  },
  { path: "/contact", component: ContactCmp,
children:[{path:"",component:FirstForm}] },
];

