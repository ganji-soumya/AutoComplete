import Vue from 'vue'
import App from './App.vue'
import { ValidationProvider ,ValidationObserver} from 'vee-validate';
import VueResource from 'vue-resource'
import {routes}from './route.js'
import VueRouter from 'vue-router'
import CustomDirective from "./components/CustomDir.vue";

Vue.use(VueRouter);

Vue.filter("to-uppercase", function (value1) {
  return value1.toUpperCase();
});

Vue.filter("to-INR", function (value) {
  return `usd.${value}`;
});


Vue.component("custom-dir", CustomDirective);
Vue.directive("colorIt", {
  bind(el,binding) {
    if(binding.arg=="color")
    {
    el.style.color = binding.value;
    }
    else{
      el.style.color="blue";
    }
    if(binding.modifiers["shadow"]){
      el.style.textShadow="5px 7px 5px grey";
    }
  },
});

const router = new VueRouter({
  routes,
  mode:'history'
  });



Vue.use ( VueResource );


Vue.component("ValidationObserver", ValidationObserver);
Vue.component("ValidationProvider", ValidationProvider);


Vue.config.productionTip = false



new Vue({
  render: h => h(App),
  router,
  watch: {},
}).$mount('#app')
