const myTheme = {
 
   main:'aqua',
    space:'200px',
    fontType: 'Times New Roman'
    };
    
 export default myTheme;