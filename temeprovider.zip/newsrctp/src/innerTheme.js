const innerTheme = {
    
    main: 'red',
    space:'50px',
    fontType: 'Times New Roman'
    };
    
 export default innerTheme;