<template>
  <div id="app">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
    
      <hr/>
      <VueAutoComplete :source="[
        {id:1, name:'Apple',Category:'A'},
        {id:2, name:'Bananamangoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',Category:'A'},
        {id:3, name:'Orange',Category:'A'},
        {id:4, name:'Mango',Category:'A'},
        {id:5, name:'Pear',Category:'B'},
        {id:6, name:'Peach',Category:'B'},
        {id:7, name:'Grape',Category:'A'},
        {id:8, name:'Tangerine',Category:'C'},
        {id:9, name:'P',Category:'A'}
      ]" :clearOnEscape="true" :disableClearable="false" :autoHighlight="true"
      :disableCloseOnSelect="false" :disabled="false"  :openOnFocus="true" 
        :debug="false" :includeInputInList="true" :freeSolo="true" 
        :disablePortal="false" 
        :disableListWrap="false"
        :multiple="true"
        :fullwidth="false"
        :blurOnSelect=""
        id="id"
        class="shape"
        disableOption="Orange"  
        selectOption="Pear"   
        getdisableOption="Orange"   />
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'

import VueAutoComplete from './components/VueAutoComplete.vue'



export default {
  name: 'App',
  
  components: {
    HelloWorld,
   
    VueAutoComplete
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

