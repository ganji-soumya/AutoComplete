<template>
  <div id="app">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
    
      <hr/>
      <VueAutoComplete :source="[
        {id:1, name:'Apple',Category:'Aaaa'},
        {id:2, name:'Banana',Category:'A'},
        {id:3, name:'Orange',Category:'Aaaa'},
        {id:4, name:'Mango',Category:'Aaa'},
        {id:5, name:'Pear',Category:'Bbcds'},
        {id:6, name:'Peach',Category:'Bswa'},
        {id:7, name:'Grape',Category:'AcEQD'},
        {id:8, name:'Tangerine',Category:'CWQDF'},
        {id:9, name:'P',Category:'A'}
      ]" :clearOnEscape="true" :disableClearable="false" :autoHighlight="true"
      :disableCloseOnSelect="false" :disabled="false"  :openOnFocus="true" 
        :debug="false" :includeInputInList="true" :freeSolo="true" 
        :disablePortal="false" 
        :disableListWrap="false"
        :multiple="true"
        :fullwidth="false"
        :blurOnSelect="false"
        id="id"
        class="shape"
        disableOption="Orange"  
        selectOption="Pear"   
        getdisableOption="Pear" 

        label="name" 

        @OnhighlightChange="OnhighlightChange($event)"
        @OnChange="OnChange($event)"
        :forcePopupIcon="true"
         />
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'

import VueAutoComplete from './components/VueAutoComplete.vue'



export default {
  name: 'App',
  
  components: {
    HelloWorld,
   
    VueAutoComplete
  },
 
  methods:{
   OnhighlightChange()
    {
      
     console.log("there is a change in focus")
     
     
    },
    OnChange(eve)
    {
      console.log("change in selection")
      console.log(eve);
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

