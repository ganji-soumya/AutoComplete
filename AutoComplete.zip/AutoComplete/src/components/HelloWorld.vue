<template>
<div>
  <popper
    trigger="click"
    :options="{
      placement: 'right',
      modifiers: { offset: { offset: '0,10px' } }
    }">
    <div class="popper">
      work
    
    </div>

    <input slot="reference"/>
    
  
  </popper>
  <div>content</div>
  </div>
</template>


<script>
import Popper from 'vue-popperjs';
export default {
  name: 'HelloWorld',
   components: {
      'popper': Popper
    },
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
