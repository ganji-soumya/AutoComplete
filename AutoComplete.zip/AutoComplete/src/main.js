import Vue from 'vue'
import App from './App.vue'
import VueAutoComplete from './components/VueAutoComplete.vue'
Vue.config.productionTip = false
Vue.use("VueAutoComplete",VueAutoComplete)

new Vue({
  
  render: h => h(App),
}).$mount('#app')
